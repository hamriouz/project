package view;
import model.*;
public class ImportExportView {
    private User user;
    private void getCommandForImportExport(){

    }

    public void showMenu(){

    }

    public void exitMenu(){

    }

    public void printExecption(Exception output){

    }

    public void printText(String output){
        System.out.println(output);
    }
}
