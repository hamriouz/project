package view;
import model.*;
public class MainView {
    private User user;

    private void getCommandForMain(){

    }

    public void printException(Exception output){

    }

    public void printText(String output){
        System.out.println(output);
    }

    public void showMenu(){

    }
    public void exitMenu(){

    }
}
