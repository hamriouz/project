package view;
import model.*;
public class ScoreBoardView {
    private User user;
    private void getCommandForScoreboard(){

    }

    public void showMenu(){

    }

    public void exitMenu(){

    }

    public void printException(Exception output){

    }

    public void printText (String output){
        System.out.println(output);
    }
}
