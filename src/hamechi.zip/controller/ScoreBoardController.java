public class ScoreBoardController {

    private User user;
 public static ScoreBoardController getInstance(User user) {

    }

    private ScoreBoardController(User user){
     this.user = user;
    }

    public boolean processCommand (String command){

    }

    private void showScoreboard(){

    }

    private Matcher getCommandMatcher (String command, String regex){

    }
}
