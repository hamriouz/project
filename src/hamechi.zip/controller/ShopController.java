package controller;

import model.Card;
import model.User;
import view.ShopView;


import java.util.regex.Matcher;

public class ShopController {
    private static ShopController instance = null;
    private User user;

    private ShopController(User user){ this.user = user; }

    public boolean processCommand (String command){

    }

    private void buyCard(String name){
        Card card = user.getCardByName(name);
        if (card != null){
            //TODO check kardane pule yaru ke balad nistam
            //sharte in if kafi budane pule
            if (){

            }
            else
                ShopView.getInstance(this.user).printText("not enough money");

        }
        else
            ShopView.getInstance(this.user).printText("there is no card with this name");

    }

    private void showAll(){

    }

    private Matcher getCommandMatcher(String command, String regex){

    }

    //TODO nemidunam ino chejuri bayad bezanam
    private void logOUtUser(){

    }
}
