package model;
public enum Icon {
    NORMAL,
    COUNTER,
    CONTINUOUS,
    QUICK_PLAY,
    FIELD,
    EQUIP,
    RITUAL
}
