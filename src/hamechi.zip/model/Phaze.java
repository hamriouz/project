package model;
public enum Phaze {
    DRAW_PHAZE,
    STANDBY_PHAZE,
    MAIN_PHAZE1,
    BATTLE_PHAZE,
    MAIN_PHAZE2,
    END_PHAZE
}
